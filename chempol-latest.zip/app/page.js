//Home Page



import PaddingContainer from "./components/layout/padding-container";
import BlogContainer from "./components/layout/blog-container";
import { getHomePage } from "@/app/data/loader"
import SpeakableSchema from "./components/elements/speakable-schema";

import { generateMetadata as generatePageMetadata } from "@/libs/metadata";
import { cache } from 'react';
import SEOSchema from "./components/elements/seo-schema";

import siteConfig from "@/config/site";

import CharcoalContentBox from "./components/layout/charcoal-content-box";

import ProductCategoryGrid from "./components/layout/product-category-grid";
import CTAcard from "./components/layout/cta-card";
import Slider from "./components/layout/slider";
import FretchVideosWrapper from "./components/elements/FretchVideosWrapper";







const cachedGetHomePage = cache(getHomePage);
export async function generateMetadata(props) {
  const params = await props.params;


  const pageData = await cachedGetHomePage();

  const metadataParams = {
    pageTitle: pageData.seo?.seoTitle ? pageData.seo?.seoTitle : pageData.title,
    pageSlug: "/",
    pageDescription: pageData.seo?.seoDesctiption ? pageData.seo?.seoDesctiption : siteConfig.description,
    seoTitle: pageData.seo?.seoTitle,
    seoDescription: pageData.seo?.seoDesctiption ? pageData.seo?.seoDesctiption : siteConfig.description,
    rebotStatus: pageData.seo?.preventIndexing,
    canonicalLinks: pageData.seo?.canonicalLinks ?? "/",
    dataPublishedTime: pageData.publishedAt,
    category: "",
    image: siteConfig.ogImage,
    imageAlternativeText: "",
    imageExt: siteConfig.ogImageExt,
  };

  return await generatePageMetadata({ type: "page", path: "", params: metadataParams });
}

export default async function Home() {



  const homeData = await cachedGetHomePage();



  return (
    <div className="bg-backgroundColor">


      <Slider />

      <SpeakableSchema pageTitle={homeData.title} pageUrl={homeData.seo?.canonicalLinks ?? "/"} />
      <SEOSchema schemaList={homeData.seo?.schema} />

      {/* <!--powering progress--> */}

      <div className=" flex flex-col h-auto md:flex-row  w-full md:space-x-2  px-4 md:px-20 mt-10 justify-center" >
        {/* <!--text--> */}
        <div className="flex flex-col text-left ">
          <h2 className=" *:first-letter: text-2xl md:text-3xl text-center font-semibold text-textBlue">Powering Progress with Innovative Chemical Solutions</h2>
          <p className="text-darkGary mt-3 text-justify text-sm font-normal  pr-5  max-w-6xl ">We are petrochemical experts specializing in the evolution and manufacturing of chemical additives for engine oils, Viscosity Index Improvers, Special Additives, Gasoline Engine Oil Additives, and Speciality Chemical Additives. Trust us for providing high-quality formulations and exceptional service.</p>
        </div>

      </div>
      {/* <!--end powering progress--> */}

      {/* <!--Cards container--> */}

      <PaddingContainer  >
        <div className="flex flex-col md:flex-row  justify-center h-auto space-y-5 md:space-y-0 md:space-x-2 lg:space-x-6  md:pb-5      mt-2 md:mt-10">

          <CharcoalContentBox title="About Chempol"
            description="Chempol is a top-tier manufacturer of Lubricant raw materials, additives, and other chemical specialities, catering to multiple industries’ needs..."
            image="/images/about-chempol.jpg" url="about-us" />

          <CharcoalContentBox title="Reliability Solutions"
            description="At Chempol, we’re your go-to partner for all your lubrication Polymer Applications, Polymer Additives, and speciality polymer needs. Our team..."
            image="/images/relaibility.jpg" url="about-us" />

          <CharcoalContentBox title="Core Values"
            description="At Chempol, we are committed to delivering exceptional results to our customters. We believe that our success is driven by our ability to inspire..."
            image="/images/caore-value.jpg" url="about-us" />


        </div>
      </PaddingContainer>
      {/* <!-- end card container--> */}


      <ProductCategoryGrid />

      <CTAcard />

      <BlogContainer />

      <div className="bg-[#F2F2F2] w-full h-auto pt-14 pb-10">

        <PaddingContainer className=" ">
          <h3 className=" text-2xl md:text-3xl text-center font-semibold text-textBlue capitalize r   ml-5 z-20" >Latest Media Updates</h3>
          <FretchVideosWrapper />
        </PaddingContainer>

      </div>
    </div>

  );
}
